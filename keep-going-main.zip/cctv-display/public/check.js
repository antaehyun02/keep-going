
// 🚨 가지고 있는 키를 모두 넣어보세요 (없으면 비워두세요)
const ITS_KEY = "d4dacf337c784ea0b9e9898b257e3e78"; 
const DATA_GO_KEY = "AgBXblXak6wS+O95/W87Cz//EWibnqETZR4NuqHiGgsoZ2etyAQHzEeajITHAVEm+mXLNfJAW4snSYa8GryHzA=="; 


*minX	double	127.00 최소 경도 영역
*maxX	double	127.30 최대 경도 영역
*minY	double	36.80 최소 위도 영역
*maxY	double	37.35 최대 위도 영역

주의운전구간 url https://openapi.its.go.kr:9443/posIncidentInfo?apiKey=d4dacf337c784ea0b9e9898b257e3e78&minX=127.05&maxX=127.25&minY=36.75&maxY=37.35&getType=json
실시간 cctv url https://openapi.its.go.kr:9443/cctvInfo?apiKey=d4dacf337c784ea0b9e9898b257e3e78&type=ex&cctvType=1&minX=127.05&maxX=127.25&minY=36.75&maxY=37.35&getType=json

돌발상황정보 url https://openapi.its.go.kr:9443/eventInfo?apiKey=d4dacf337c784ea0b9e9898b257e3e78&type=ex&eventType=all&minX=127.05&maxX=127.25&minY=36.75&maxY=37.35&getType=json

도로전광표지(VMS)정보 https://openapi.its.go.kr:9443/vmsInfo?apiKey=d4dacf337c784ea0b9e9898b257e3e78&getType=json




