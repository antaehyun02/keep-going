import pandas as pd
import numpy as np
import glob
import sys
import json
import io
from sklearn.ensemble import RandomForestRegressor

# 표준 출력의 인코딩을 UTF-8로 설정 (Node.js에서 한글 깨짐 방지)
sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding='utf-8')

# 1. Node.js에서 전달받은 인자 파싱
# 실행 예: python ai_server.py <DayOfWeek> <Hour>
try:
    current_day = int(sys.argv[1]) # 0(일) ~ 6(토) 주의: JS는 일요일이 0
    current_hour = int(sys.argv[2])
except:
    # 인자가 없을 경우 기본값
    current_day = 0
    current_hour = 12

folder_path = 'data/' 

# --- 데이터 로드 및 전처리 (기존 로직 유지) ---
vds_files = glob.glob(folder_path + '*VDS*.csv')
vds_grouped = pd.DataFrame()

# (데이터 로딩 부분은 코드 길이상 생략하지 않고 로직 그대로 유지)
if vds_files:
    vds_list = []
    for f in vds_files:
        try:
            df = pd.read_csv(f)
            if 'VDS_CD' in df.columns:
                df = df[df['VDS_CD'].astype(str).str.startswith('0010')]
                vds_list.append(df)
        except: continue
    if vds_list:
        vds_all = pd.concat(vds_list, ignore_index=True)
        vds_grouped = vds_all.groupby(['SUM_YRMTHDAT', 'SUM_HR'])[['OCCPNCY']].mean().reset_index()
        vds_grouped.columns = ['DateInt', 'Hour', 'Avg_Occupancy']

czn_files = glob.glob(folder_path + '*CZN*.csv')
czn_df = pd.DataFrame()
target_segments = [
    ('오산IC', '남사진위IC'), ('남사진위IC', '안성JC'),
    ('안성JC', '안성IC'), ('안성IC', '북천안IC'), ('북천안IC', '천안IC')
]

if czn_files:
    czn_list = []
    for f in czn_files:
        try:
            df = pd.read_csv(f)
            for s, e in target_segments:
                mask = (df['ST_ND_NM'] == s) & (df['END_ND_NM'] == e)
                if mask.any():
                    sub = df[mask].copy()
                    sub['Section_Name'] = f"{s}→{e}"
                    czn_list.append(sub)
        except: continue
    if czn_list:
        czn_df = pd.concat(czn_list, ignore_index=True)

# --- 모델 학습 및 예측 ---
response_data = {
    "status": "error",
    "message": "데이터 부족"
}

if not czn_df.empty and not vds_grouped.empty:
    merged = pd.merge(czn_df, vds_grouped, left_on=['SUM_YRMTHDAT', 'SUM_HR'], right_on=['DateInt', 'Hour'], how='left')
    merged['Date'] = pd.to_datetime(merged['SUM_YRMTHDAT'], format='%Y%m%d')
    merged['DayOfWeek'] = merged['Date'].dt.dayofweek # 월=0, 일=6
    merged['Is_Weekend'] = merged['DayOfWeek'].apply(lambda x: 1 if x >= 5 else 0)
    
    merged['Section_Name'] = merged['Section_Name'].astype('category')
    merged['Section_ID'] = merged['Section_Name'].cat.codes
    section_map = {name: i for i, name in enumerate(merged['Section_Name'].cat.categories)}

    history_stats = merged.groupby(['DayOfWeek', 'SUM_HR'])['Avg_Occupancy'].mean().reset_index()

    X = merged[['SUM_HR', 'DayOfWeek', 'Is_Weekend', 'Section_ID', 'Avg_Occupancy']]
    y = merged['PASNG_RUNTM_MINS']
    
    mask = X['Avg_Occupancy'].notnull() & y.notnull()
    
    # 모델 학습 (실제 서비스에서는 미리 학습된 모델(.pkl)을 로드하는 것이 성능상 좋습니다)
    model = RandomForestRegressor(n_estimators=50, random_state=42) # 속도를 위해 estimators 줄임
    model.fit(X[mask], y[mask])

    # --- 예측 실행 ---
    # JS의 getDay()는 일=0, 월=1... 토=6
    # Python dt.dayofweek는 월=0... 일=6
    # 변환 로직: JS(0,일) -> Py(6), JS(1~6) -> Py(0~5)
    py_day = 6 if current_day == 0 else current_day - 1
    
    is_weekend = 1 if py_day >= 5 else 0
    
    # 해당 요일/시간의 평소 혼잡도 조회
    row = history_stats[(history_stats['DayOfWeek'] == py_day) & (history_stats['SUM_HR'] == current_hour)]
    avg_congestion = row['Avg_Occupancy'].values[0] if not row.empty else 5.0
    
    total_time = 0
    for start, end in target_segments:
        sec_name = f"{start}→{end}"
        if sec_name in section_map:
            sec_id = section_map[sec_name]
            # 예측 (구간별 소요시간 합산)
            pred = model.predict([[current_hour, py_day, is_weekend, sec_id, avg_congestion]])[0]
            total_time += pred

    total_mins = int(total_time / 60)
    
    # 결과 JSON 구성
    response_data = {
        "status": "success",
        "day": py_day,
        "hour": current_hour,
        "predicted_time_min": total_mins,
        "avg_congestion": round(avg_congestion, 1),
        "traffic_status": "원활" if avg_congestion < 5 else ("서행" if avg_congestion < 15 else "정체")
    }

# 최종 결과를 JSON 문자열로 출력 (이것을 Node.js가 읽음)
print(json.dumps(response_data, ensure_ascii=False))