# keep-going
pip install pandas scikit-learn numpy
npm init -y
npm install express axios
node server.js
